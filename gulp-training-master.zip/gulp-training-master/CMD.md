# Установка терминала CMD для VSCode по умолчанию (для Windows)

1. Выполните команду меню **Terminal** >> **New terminal**

![how to add cmd to vscode by default](assets/img/vscode-cmd/1.png)

2. В окне терминалов разверните список и выберите **Select Default Profile**

![how to add cmd to vscode by default](assets/img/vscode-cmd/2.png)

3. В появшемся окне выберите **Command Prompt**

![how to add cmd to vscode by default](assets/img/vscode-cmd/3.png)

4. Закройте терминал Powershall и откройте заново окно терминалов, или перезапустите VSCode
